@echo off
cd /d "%~dp0"
py -3 -m pip install --upgrade pymupdf pillow pdf2docx python-docx pywin32
pause

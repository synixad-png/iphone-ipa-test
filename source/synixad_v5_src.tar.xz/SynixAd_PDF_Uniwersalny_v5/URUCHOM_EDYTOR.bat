@echo off
cd /d "%~dp0"
py -3 -c "import fitz,PIL,pdf2docx" >nul 2>&1
if errorlevel 1 (
 echo Brak zaleznosci. Trwa instalacja potrzebnych bibliotek...
 py -3 -m pip install --upgrade pymupdf pillow pdf2docx python-docx pywin32
 if errorlevel 1 (
  echo Instalacja nie powiodla sie. Uruchom INSTALUJ_ZALEZNOSCI.bat
  pause
  exit /b 1
 )
)
py -3 SynixAd_PDF.py
if errorlevel 1 pause

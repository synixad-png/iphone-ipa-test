"""Uniwersalny SynixAd PDF v5: original PDF editor + editable DOCX conversion."""
import os
import sys
import shutil
import subprocess
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path
from edytor_pdf import App


def launch_file(path):
    if sys.platform == 'win32':
        os.startfile(str(path))
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', str(path)])
    else:
        subprocess.Popen(['xdg-open', str(path)])


def convert_pdf_to_docx(pdf, target):
    from pdf2docx import Converter
    cv = Converter(str(pdf))
    try:
        cv.convert(str(target), start=0, end=None)
    finally:
        cv.close()
    if not target.exists() or target.stat().st_size < 500:
        raise RuntimeError('Konwersja nie utworzyła poprawnego pliku DOCX.')

class UniversalPDF(App):
    def __init__(self, root):
        super().__init__(root)
        self.root.title('SynixAd PDF v5 — edytor uniwersalny')
        self.add_word_bar()

    def add_word_bar(self):
        panel=ttk.Frame(self.root,padding=(8,6))
        # Main toolbar remains first, additional strip above scroll area.
        panel.pack(before=self.canvas.master,fill='x')
        ttk.Button(panel,text='EDYTUJ JAK W WORDZIE — konwertuj do DOCX',
                   command=self.word_mode).pack(side='left',padx=(0,8))
        ttk.Button(panel,text='Otwórz edytowany DOCX',
                   command=self.open_docx).pack(side='left',padx=(0,8))
        ttk.Button(panel,text='DOCX → PDF',command=self.docx_to_pdf).pack(side='left')
        ttk.Label(panel,text='  Tryb PDF zachowuje wygląd | Tryb DOCX umożliwia edycję akapitów i tabel',
                  foreground='#3c5369').pack(side='left',padx=8)
        self.root.geometry('1420x910')

    def word_mode(self):
        pdf = self.path
        if not pdf:
            pdf=filedialog.askopenfilename(title='Wybierz plik PDF',filetypes=[('PDF','*.pdf')])
        if not pdf:return
        source=Path(pdf)
        target_str=filedialog.asksaveasfilename(title='Gdzie zapisać edytowalny dokument?',
            defaultextension='.docx',initialfile=source.stem+'_DO_EDYCJI.docx',
            filetypes=[('Dokument Word','*.docx')])
        if not target_str:return
        target=Path(target_str)
        if target.resolve()==source.resolve():
            messagebox.showerror('Błąd','Plik docelowy musi być inny niż źródłowy.');return
        self.root.config(cursor='watch');self.root.update_idletasks()
        try:
            convert_pdf_to_docx(source,target)
            self.status.config(text=f'DOCX gotowy: {target} | sprawdź układ po konwersji')
            if messagebox.askyesno('DOCX gotowy',
                f'Zapisano edytowalny dokument:\n{target}\n\n'
                'Otworzyć go w programie Word lub LibreOffice?\n\n'
                'W skomplikowanych PDF układ może różnić się od oryginału.'):
                launch_file(target)
        except ImportError:
            messagebox.showerror('Brak modułu','Brak biblioteki pdf2docx. Uruchom INSTALUJ_ZALEZNOSCI.bat.');
        except Exception as ex:
            messagebox.showerror('Konwersja nieudana',f'{ex}\n\nNie każdy PDF da się automatycznie przekształcić w edytowalny dokument.')
        finally:self.root.config(cursor='')

    def open_docx(self):
        path=filedialog.askopenfilename(filetypes=[('Word DOCX','*.docx')]);
        if path:
            try:launch_file(path)
            except Exception as ex:messagebox.showerror('Nie można otworzyć DOCX',str(ex))

    def docx_to_pdf(self):
        src=filedialog.askopenfilename(title='Wybierz edytowany DOCX',filetypes=[('Word DOCX','*.docx')]);
        if not src:return
        result=filedialog.asksaveasfilename(title='Zapisz PDF jako',defaultextension='.pdf',
                initialfile=Path(src).stem+'.pdf',filetypes=[('PDF','*.pdf')])
        if not result:return
        out=Path(result);temp=out.with_name(out.stem+'_synix_temp')
        if out.resolve()==Path(src).resolve():return
        try:
            if sys.platform=='win32':
                try:
                    import win32com.client
                    word=win32com.client.DispatchEx('Word.Application')
                    word.Visible=False
                    doc=None
                    try:
                        doc=word.Documents.Open(os.path.abspath(src),ReadOnly=True)
                        doc.ExportAsFixedFormat(os.path.abspath(result),17)
                    finally:
                        if doc:doc.Close(False)
                        word.Quit()
                    messagebox.showinfo('Gotowe',f'Zapisano PDF:\n{result}');return
                except ImportError:pass
            lo=shutil.which('soffice') or shutil.which('libreoffice')
            if not lo and sys.platform=='win32':
                for candidate in [r'C:\Program Files\LibreOffice\program\soffice.exe',
                                  r'C:\Program Files (x86)\LibreOffice\program\soffice.exe']:
                    if os.path.isfile(candidate):lo=candidate;break
            if not lo:
                raise RuntimeError('Eksport wymaga Microsoft Word + pywin32 lub LibreOffice.\n'
                                   'Możesz też zapisać PDF bezpośrednio w Wordzie: Plik → Eksportuj → PDF.')
            temp.mkdir(exist_ok=True)
            result_process=subprocess.run([lo,'-env:UserInstallation=file:///tmp/synix_pdf_convert',
                '--headless','--convert-to','pdf','--outdir',str(temp),src],
                text=True,capture_output=True,timeout=180)
            generated=temp/(Path(src).stem+'.pdf')
            if result_process.returncode or not generated.exists():
                raise RuntimeError(result_process.stderr or result_process.stdout or 'Eksport nieudany')
            shutil.move(str(generated),str(out))
            messagebox.showinfo('Gotowe',f'Zapisano PDF:\n{out}')
        except Exception as ex:messagebox.showerror('Eksport nieudany',str(ex))
        finally:
            if temp.exists():
                try:temp.rmdir()
                except OSError:pass

if __name__=='__main__':
    root=tk.Tk()
    app=UniversalPDF(root)
    if len(sys.argv)>1 and Path(sys.argv[1]).is_file():
        # The normal Open PDF button works with every file; opening on CLI optional.
        pass
    root.mainloop()

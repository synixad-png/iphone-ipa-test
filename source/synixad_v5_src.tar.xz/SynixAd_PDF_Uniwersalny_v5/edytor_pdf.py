"""SynixAd PDF v4: inline typing on faithful PDF pages (not full reflow editing)."""
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, font as tkfont
from dataclasses import dataclass
import fitz
from PIL import Image, ImageTk, ImageDraw, ImageFont


def unicode_font():
    for name in (r'C:\Windows\Fonts\arial.ttf', r'C:\Windows\Fonts\calibri.ttf',
                 '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        if os.path.isfile(name):
            return name
    return None

FONTFILE = unicode_font()

@dataclass
class Change:
    page: int
    rect: tuple
    text: str
    size: float
    width: float
    original: str = ''
    rgb: tuple = (0.,0.,0.)


def wrapped_lines(text, font, width):
    """Approximate canvas and PDF line splitting at word boundaries."""
    out = []
    for paragraph in text.split('\n'):
        if not paragraph:
            out.append(''); continue
        words = paragraph.split(' ')
        line = ''
        for word in words:
            candidate = (line + ' ' + word) if line else word
            if font.getlength(candidate) <= width or not line:
                line = candidate
            else:
                out.append(line); line = word
        out.append(line)
    return out

class App:
    def __init__(self, root):
        self.root=root
        self.root.title('SynixAd — PDF v4 | Edycja bezpośrednio na stronie')
        root.geometry('1280x900')
        self.doc=None; self.path=None; self.page=0; self.zoom=1.4
        self.changes=[]; self.photo=None; self.spans=[]; self.editbox=None
        self.edit_window=None; self.active=None; self.active_idx=None
        self.auto_committing=False
        self.size_var=tk.StringVar(value='10')
        self.width_var=tk.StringVar(value='220')
        self.build()

    def build(self):
        bar=ttk.Frame(self.root,padding=6); bar.pack(fill='x')
        for label,fn in [('Otwórz PDF',self.open),('Zapisz PDF jako...',self.save),
                         ('Cofnij zmianę',self.undo),('Zakończ pisanie',self.finish)]:
            ttk.Button(bar,text=label,command=fn).pack(side='left',padx=3)
        ttk.Separator(bar,orient='vertical').pack(side='left',fill='y',padx=7)
        ttk.Button(bar,text='◀',command=self.previous,width=3).pack(side='left')
        self.page_label=ttk.Label(bar,text='— / —',width=12,anchor='center');self.page_label.pack(side='left')
        ttk.Button(bar,text='▶',command=self.next,width=3).pack(side='left')
        ttk.Button(bar,text='−',command=lambda:self.change_zoom(-.2),width=3).pack(side='left',padx=(12,1))
        self.zoom_label=ttk.Label(bar,text='140%',width=7); self.zoom_label.pack(side='left')
        ttk.Button(bar,text='+',command=lambda:self.change_zoom(.2),width=3).pack(side='left')
        ttk.Label(bar,text='  Wielkość (pt):').pack(side='left')
        ttk.Spinbox(bar,from_=5,to=72,increment=1,width=5,textvariable=self.size_var).pack(side='left')
        ttk.Label(bar,text='  Szerokość pisania (pt):').pack(side='left')
        ttk.Spinbox(bar,from_=30,to=550,increment=10,width=6,textvariable=self.width_var).pack(side='left')
        ttk.Button(bar,text='Zastosuj rozmiary',command=self.resize_box).pack(side='left',padx=6)
        helpbar=ttk.Frame(self.root,padding=(9,0,9,7));helpbar.pack(fill='x')
        ttk.Label(helpbar,text='Kliknij tekst lub puste miejsce i pisz NA STRONIE. Enter = kolejny wiersz, Ctrl+Enter = zatwierdź, Esc = anuluj. Ctrl+Z działa podczas pisania.',foreground='#075b8d').pack(anchor='w')
        ttk.Label(helpbar,text='Układ PDF jest stały: wpisywanie NIE przesuwa automatycznie innych tabel i akapitów.',foreground='#985a06').pack(anchor='w')
        host=ttk.Frame(self.root);host.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(host,bg='#777e88',highlightthickness=0)
        v=ttk.Scrollbar(host,orient='vertical',command=self.canvas.yview)
        h=ttk.Scrollbar(host,orient='horizontal',command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=v.set,xscrollcommand=h.set)
        v.pack(side='right',fill='y');h.pack(side='bottom',fill='x');self.canvas.pack(side='left',fill='both',expand=True)
        self.canvas.bind('<Button-1>',self.click)
        self.canvas.bind('<MouseWheel>',lambda e:self.canvas.yview_scroll(-int(e.delta/120),'units'))
        self.status=ttk.Label(self.root,text='Otwórz plik PDF.',relief='sunken',padding=5)
        self.status.pack(side='bottom',fill='x')
        self.root.bind('<Control-o>',lambda e:self.open())
        self.root.bind('<Control-Shift-S>',lambda e:self.save())
        self.root.bind('<Control-z>',self.global_undo)
        self.root.bind('<Prior>',lambda e:self.previous())
        self.root.bind('<Next>',lambda e:self.next())

    def open(self):
        path=filedialog.askopenfilename(filetypes=[('PDF','*.pdf')]);
        if not path:return
        self.finish()
        if self.changes and not messagebox.askyesno('Zmiany','Otworzyć nowy PDF? Niezapisane zmiany znikną.'):
            return
        try:
            doc=fitz.open(path)
            if doc.needs_pass:
                from tkinter import simpledialog
                pw=simpledialog.askstring('Hasło','Hasło PDF:',show='*')
                if not pw or not doc.authenticate(pw):doc.close();return
            if not len(doc):raise ValueError('PDF nie ma stron')
        except Exception as exc:messagebox.showerror('Otwieranie',str(exc));return
        if self.doc:self.doc.close()
        self.doc=doc;self.path=path;self.page=0;self.changes=[]
        self.root.title('SynixAd — PDF v4 | '+os.path.basename(path))
        self.render()

    def extract_spans(self,page):
        spans=[]
        for block in page.get_text('dict')['blocks']:
            if block.get('type')!=0:continue
            for ln in block['lines']:
                for sp in ln['spans']:
                    if sp['text'].strip():
                        spans.append((tuple(sp['bbox']),sp['text'],max(5.,float(sp['size'])),
                                     tuple(((sp['color']>>shift)&255)/255 for shift in (16,8,0))))
        return spans

    def font_preview(self,pt):
        try:return ImageFont.truetype(FONTFILE,max(7,int(pt*self.zoom))) if FONTFILE else ImageFont.load_default()
        except Exception:return ImageFont.load_default()

    def render(self):
        self.destroy_editor()
        self.canvas.delete('all')
        if not self.doc:return
        pg=self.doc[self.page]; pix=pg.get_pixmap(matrix=fitz.Matrix(self.zoom,self.zoom),alpha=False)
        im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
        draw=ImageDraw.Draw(im);self.spans=self.extract_spans(pg)
        for item in self.changes:
            if item.page!=self.page:continue
            x,y,x1,y1=item.rect
            if item.original:
                draw.rectangle((x*self.zoom,y*self.zoom,x1*self.zoom,y1*self.zoom),fill='white')
            f=self.font_preview(item.size)
            rgb=tuple(round(c*255) for c in item.rgb)
            lines=wrapped_lines(item.text,f,max(10,item.width*self.zoom-5))
            for i,line in enumerate(lines):
                draw.text((x*self.zoom,(y+i*item.size*1.30)*self.zoom),line,font=f,fill=rgb)
            box_height=max(item.size*1.4,len(lines)*item.size*1.3)
            draw.rectangle((x*self.zoom-1,y*self.zoom-1,(x+item.width)*self.zoom+1,(y+box_height)*self.zoom+1),outline='#3b82f6',width=1)
        self.photo=ImageTk.PhotoImage(im)
        self.canvas.create_image(24,20,anchor='nw',image=self.photo)
        self.canvas.configure(scrollregion=(0,0,pix.width+48,pix.height+40))
        self.page_label.configure(text=f'{self.page+1} / {len(self.doc)}')
        self.zoom_label.configure(text=f'{int(self.zoom*100)}%')
        self.status.configure(text=f'{os.path.basename(self.path)} | {len(self.changes)} zmiany | oryginalna grafika PDF zachowana')

    def click(self,event):
        if not self.doc:return
        self.finish()
        x=(self.canvas.canvasx(event.x)-24)/self.zoom
        y=(self.canvas.canvasy(event.y)-20)/self.zoom
        pg=self.doc[self.page]
        if not (0<=x<=pg.rect.width and 0<=y<=pg.rect.height):return
        for n in range(len(self.changes)-1,-1,-1):
            c=self.changes[n]
            if c.page==self.page and c.rect[0]-3<=x<=c.rect[0]+c.width+3 and c.rect[1]-3<=y<=c.rect[1]+max(c.size*1.3,c.text.count('\n')*c.size*1.3)+3:
                self.start_editor(c,n);return
        matches=[s for s in self.spans if s[0][0]-2<=x<=s[0][2]+2 and s[0][1]-2<=y<=s[0][3]+2]
        if matches:
            rect,text,size,rgb=min(matches,key=lambda sp:(sp[0][2]-sp[0][0])*(sp[0][3]-sp[0][1]))
            width=max(80.,rect[2]-rect[0]+15)
            width=min(width,pg.rect.width-rect[0]-10)
            self.start_editor(Change(self.page,rect,text,size,width,text,rgb),None)
        else:
            size=10.
            try:size=float(self.size_var.get().replace(',','.'))
            except ValueError:pass
            width=min(220.,pg.rect.width-x-8)
            self.start_editor(Change(self.page,(x,y,x+1,y+size*1.3),'',size,width),None)

    def start_editor(self,change,index):
        self.destroy_editor()
        self.active=Change(**vars(change));self.active_idx=index
        self.size_var.set(f'{change.size:g}');self.width_var.set(f'{change.width:g}')
        self.editbox=tk.Text(self.canvas,undo=True,wrap='word',borderwidth=1,relief='solid',
                             padx=2,pady=2,insertwidth=2,highlightthickness=1,highlightcolor='#1976d2')
        self.editbox.insert('1.0',change.text)
        self.editbox.config(font=('Arial',max(7,round(change.size*self.zoom))),
                            fg='#111111',bg='#fffef5')
        px=round(change.width*self.zoom)
        height=self.editor_height(change.text,change.size,px)
        self.editbox.config(width=1,height=1)
        x,y,*_=change.rect
        self.edit_window=self.canvas.create_window(24+x*self.zoom,20+y*self.zoom,anchor='nw',
                                                   window=self.editbox,width=px,height=height)
        self.editbox.bind('<Control-Return>',self._confirm)
        self.editbox.bind('<Escape>',self._cancel)
        self.editbox.bind('<<Modified>>',self._modified)
        self.editbox.bind('<FocusOut>',lambda _e:self.root.after_idle(self._finish_if_unfocused))
        self.editbox.edit_modified(False)
        self.editbox.focus_set()
        self.editbox.mark_set('insert','end-1c')
        self.editbox.see('insert')
        self.status.configure(text='PISANIE NA STRONIE | Ctrl+Enter = zatwierdź | Esc = anuluj | Zaznaczaj tekst myszą')

    def editor_height(self,text,pt,width_px):
        # Tk Text does the actual wrapping. Reserve a generous area for wrapping and grows as you type.
        chars=max(5,int(width_px/max(4,pt*self.zoom*.53)))
        count=sum(max(1,(len(line)+chars-1)//chars) for line in text.split('\n'))
        return max(31,int((count+1)*pt*self.zoom*1.55+8))

    def _modified(self,_event):
        if self.editbox and self.editbox.edit_modified():
            self.editbox.edit_modified(False)
            if self.active:
                txt=self.editbox.get('1.0','end-1c')
                height=self.editor_height(txt,self.active.size,round(self.active.width*self.zoom))
                self.canvas.itemconfigure(self.edit_window,height=min(height,self.doc[self.page].rect.height*self.zoom))

    def _finish_if_unfocused(self):
        if self.editbox and self.root.focus_get()!=self.editbox:self.finish()

    def _confirm(self,_event=None):
        self.finish();return 'break'

    def _cancel(self,_event=None):
        self.destroy_editor();self.active=None;self.active_idx=None;self.render();return 'break'

    def destroy_editor(self):
        if self.editbox:
            self.editbox.destroy();self.editbox=None
        if self.edit_window:
            self.canvas.delete(self.edit_window);self.edit_window=None

    def finish(self):
        if not self.editbox or not self.active or self.auto_committing:return
        self.auto_committing=True
        try:
            txt=self.editbox.get('1.0','end-1c');change=self.active
            change.text=txt
            if self.active_idx is not None:
                self.changes[self.active_idx]=change
            elif txt!=change.original:
                self.changes.append(change)
            self.destroy_editor();self.active=None;self.active_idx=None
            self.render()
        finally:self.auto_committing=False

    def resize_box(self):
        if not self.editbox or not self.active:return
        try:
            size=float(self.size_var.get().replace(',','.'))
            width=float(self.width_var.get().replace(',','.'))
            if not 5<=size<=72 or not 30<=width<=550:raise ValueError('Wielkość 5–72 pt, szerokość 30–550 pt.')
            self.active.size=size
            self.active.width=min(width,self.doc[self.page].rect.width-self.active.rect[0]-4)
            if self.active.width<15:raise ValueError('Brak miejsca do prawej krawędzi strony.')
            self.editbox.config(font=('Arial',max(7,round(size*self.zoom))))
            self.canvas.itemconfigure(self.edit_window,width=round(self.active.width*self.zoom))
            self._modified(None)
        except Exception as exc:messagebox.showwarning('Rozmiar',str(exc))

    @staticmethod
    def apply(doc,changes,fontfile):
        # Remove glyphs only, never paths or images; preserve all untouched content.
        for page_idx in sorted(set(c.page for c in changes)):
            pg=doc[page_idx]; local=[c for c in changes if c.page==page_idx]
            for c in local:
                if c.original:
                    r=fitz.Rect(c.rect)
                    r.y0+=min(.25,r.height/12);r.y1-=min(.25,r.height/12)
                    pg.add_redact_annot(r,fill=False,cross_out=False)
            if any(c.original for c in local):pg.apply_redactions(images=0,graphics=0,text=0)
            if fontfile:
                pg.insert_font(fontname='SynixFont',fontfile=fontfile)
                font='SynixFont'
            else:font='helv'
            for c in local:
                if not c.text:continue
                # Use explicit lines for reliable wrapping and correct Unicode font.
                try:
                    pilfont=ImageFont.truetype(fontfile,max(10,round(c.size*3))) if fontfile else ImageFont.load_default()
                    lines=wrapped_lines(c.text,pilfont,max(12,c.width*3-9))
                except Exception:lines=c.text.split('\n')
                baseline=c.rect[1]+c.size*1.05
                for line in lines:
                    if line:
                        pg.insert_text((c.rect[0],baseline),line,fontname=font,fontsize=c.size,color=c.rgb,overlay=True)
                    baseline+=c.size*1.30
                if baseline-c.size*.1>pg.rect.height+3:
                    raise ValueError(f'Tekst na stronie {page_idx+1} wychodzi poza dolną krawędź PDF.')
        return doc

    def save(self):
        if not self.doc:return
        self.finish()
        out=filedialog.asksaveasfilename(defaultextension='.pdf',initialfile=os.path.splitext(os.path.basename(self.path))[0]+'_EDYCJA.pdf',filetypes=[('PDF','*.pdf')])
        if not out:return
        if os.path.normcase(os.path.abspath(out))==os.path.normcase(os.path.abspath(self.path)):
            messagebox.showwarning('Zapis','Wybierz inną nazwę niż oryginał.');return
        try:
            copy=fitz.open(stream=self.doc.tobytes(),filetype='pdf')
            self.apply(copy,self.changes,FONTFILE)
            copy.save(out,garbage=4,deflate=True);copy.close()
            with fitz.open(out) as check:
                if len(check)!=len(self.doc):raise ValueError('Błędna liczba stron po zapisaniu')
            messagebox.showinfo('Zapisano','Zapisano PDF:\n'+out+'\n\nOryginał bez zmian.')
        except Exception as exc:messagebox.showerror('Błąd zapisu',str(exc))

    def undo(self):
        if self.editbox:
            try:self.editbox.edit_undo()
            except tk.TclError:pass
            return
        if self.changes:self.changes.pop();self.render()

    def global_undo(self,event):
        self.undo();return 'break'

    def previous(self):
        self.finish()
        if self.doc and self.page>0:self.page-=1;self.render()
    def next(self):
        self.finish()
        if self.doc and self.page<len(self.doc)-1:self.page+=1;self.render()
    def change_zoom(self,step):
        self.finish();self.zoom=round(min(3,max(.6,self.zoom+step)),2);self.render()

if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
